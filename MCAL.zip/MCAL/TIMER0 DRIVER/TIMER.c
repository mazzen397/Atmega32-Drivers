/*
 * TIMER.c
 *
 * Created: 7/16/2023 11:05:39 PM
 *  Author: Mazzen397
 */ 
#include "TIMER.h"

uint32_t overFlowCounter = 0;
void timer_init(void){
	//1. Choose Timer Mode
	TCCR0 = 0x00; //Normal Mode
	
	//2. Set Timer initial value
	TCNT0 = 0x00;
	
}

void timer_start(void){
	
	//3. Start Timer
	//Choose Pre-scaler
	TCCR0 |= (1 << CS00);
	while (overFlowCounter < NumberOfOverFlows){
		//4. Stop after Number of overflows 
		//Wait until the overflow to be 1
		while((TIFR & (1 << TOV0)) == 0);
		
		//5. Clear the overflow
		TIFR |= (1 << TOV0);
		
		overFlowCounter++;
	}
	overFlowCounter = 0;
	
	//6. Stop the Timer
	TCCR0 = 0x00;
}