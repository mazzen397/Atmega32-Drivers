/*
 * TIMER.h
 *
 * Created: 7/16/2023 11:05:46 PM
 *  Author: Mazzen397
 */ 


#ifndef TIMER_H_
#define TIMER_H_

#include "../../Register.h"
#define NumberOfOverFlows 60
//TCCR0 Pins
#define CS00 0
#define CS01 1
#define CS02 2

//TIFR Pins
#define TOV0 0
#define OCF0 1

//Function Prototypes
void timer_init(void);
void timer_start(void);
#endif /* TIMER_H_ */