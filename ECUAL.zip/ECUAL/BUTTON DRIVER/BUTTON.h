/*
 * BUTTON.h
 *
 * Created: 7/15/2023 6:18:51 PM
 *  Author: Mazzen397
 */ 


#ifndef BUTTON_H_
#define BUTTON_H_

#include "../../MCAL/DIO DRIVER/DIO.h"
#include "../../MCAL/TIMER0 DRIVER/TIMER.h"
#include "../../MCAL/ISR DRIVER/ISR.h"

//Define Button Ports & Pins
#define BUTTON_PORT PORT_D
#define BUTTON_PIN 2

//button states
#define Button_Low 0
#define Button_High 1

//Function Prototypes
void BUTTON_init(uint8_t BUTTON_Port,uint8_t BUTTON_Pin);
void BUTTON_read(uint8_t BUTTON_Port, uint8_t BUTTON_Pin, uint8_t *value);


#endif /* BUTTON_H_ */