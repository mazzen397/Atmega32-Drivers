/*
 * BUTTON.c
 *
 * Created: 7/15/2023 6:18:59 PM
 *  Author: Mazzen397
 */ 
#include "BUTTON.h"

void BUTTON_init(uint8_t BUTTON_Port,uint8_t BUTTON_Pin){
	DIO_init(BUTTON_Pin, BUTTON_Port, IN);
}
void BUTTON_read(uint8_t BUTTON_Port, uint8_t BUTTON_Pin, uint8_t *value){
	DIO_read(BUTTON_Pin, BUTTON_Port, value);
}