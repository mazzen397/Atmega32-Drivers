/*
 * KEYPAD.c
 *
 * Created: 7/18/2023 9:58:34 PM
 *  Author: Mazzen397
 */ 
#include "KEYPAD.h"

// Define the keypad layout and the corresponding key values
const char keypad_layout[4][4] = {
	{'7', '8', '9', '/'},
	{'4', '5', '6', '*'},
	{'1', '2', '3', '-'},
	{'c', '0', '=', '+'}
};

void keypad_init(void) {
	 // Set the row pins as inputs with internal pull-ups
	 DDRA &= 0x0F;
	 PORTA |= 0xF0;

	 // Set the column pins as inputs with pull-up resistors
	 DDRA &= 0xF0;
	 PORTA |= 0x0F;
}

uint8_t keypad_getKey(void){
	for (uint8_t col = 0; col < 4; col++) {
		// Set the column pin as output low
		DDRA |= (1 << (col + 4));
		PORTA &= ~(1 << (col + 4));

		for (uint8_t row = 0; row < 4; row++) {
			// Check the state of the row pins
			if (!(PINA & (1 << row))) {
				// Calculate the pressed key based on the row and column
				return keypad_layout[row][col];
			}
		}

		// Reset the column pin as input with pull-up resistor
		PORTA |= (1 << (col + 4));
		DDRA &= ~(1 << (col + 4));
	}

	return '\0'; // No key is pressed
}

