/*
 * APP.c
 *
 * Created: 7/16/2023 11:12:39 PM
 *  Author: Mazzen397
 */ 
#include "APP.h"
uint8_t Welcome[] = "Press a Key!" ;
void APP_init(void){
	// Initialize LCD
	LCD_4_bit_init();
	// Initialize keypad
	keypad_init();
	
	//Clear LCD and Display a Welcome Message
	LCD_4_bit_Clear();
	LCD_4_bit_sendString(Welcome);
	_delay_ms(1000);
	LCD_4_bit_Clear();
}
void APP_start(void) {
	while (1)
	{
		uint8_t key = keypad_getKey();
		// Check if a key is pressed
		if (key != '\0' && key != 'c') {
			// Display the pressed key on the LCD
			LCD_4_bit_sendChar(key);

			// Wait for a short delay to prevent multiple reads for the same key press
			_delay_ms(500);
		}
		else if (key == 'c')
		{
			LCD_4_bit_Clear();
		}
	}
}

