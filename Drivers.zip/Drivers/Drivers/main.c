/*
 * Drivers.c
 *
 * Created: 7/15/2023 3:24:45 PM
 * Author : Mazzen397
 */ 

#include "APP/APP.h"

int main(void)
{	
	APP_init();
	APP_start();
}
