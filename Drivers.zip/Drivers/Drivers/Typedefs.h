/*
 * Typedefs.h
 *
 * Created: 7/15/2023 3:30:27 PM
 *  Author: Mazzen397
 */ 


#ifndef TYPEDEFS_H_
#define TYPEDEFS_H_

typedef unsigned char uint8_t;
//typedef unsigned short int uint16_t;
//typedef unsigned int uint32_t;
//typedef unsigned long long uint64_t;

#endif /* TYPEDEFS_H_ */