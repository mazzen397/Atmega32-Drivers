/*
 * ADC.c
 *
 * Created: 7/18/2023 8:49:58 PM
 *  Author: Mazzen397
 */ 
#include "ADC.h"

void ADC_init(){
	//1. Set ADC Channel 0 to be input
	DIO_init(ADC_CH_0, PORT_A, IN);
	
	//2. Choose Channel 0, single ended, AVCC refrence, adjust right
	ADMUX |= (1<<6);
	
	//3. Enable ADC with /2 Prescaler and no interrupts
	ADCSRA |= (1<<7);
}
void ADC_start(){
	
uint16_t analogVoltageValue = 0, tempValue = 0, digitalVoltageValue = 0;
float sensorValue = 0.0;

	//1. Choose Channel to Read
	ADMUX |= (ADC_CH_0 & 0x0F);
	
	//2. Start Conversion
	ADCSRA |= (1<<6);
	
	//3. Wait for Conversion complete flag
	while ((ADCSRA & (1<<4)) == 0);
	
	//4. Read the digital value
	PORTC = ADCL;
	PORTD = ADCH;
	
	//5. Convert to Analog Value
	analogVoltageValue = digitalVoltageValue * ADC_STEP;
	
	//6. Get the final analog value
	sensorValue = analogVoltageValue / SENSOR_RESOLUTION;
}