/*
 * ISR.h
 *
 * Created: 7/17/2023 11:51:29 AM
 *  Author: Mazzen397
 */ 


#ifndef ISR_H_
#define ISR_H_

#include "../../Register.h"

//MCU Control Register - MCUCR Pins
#define ISC00 0
#define ISC01 1
#define ISC10 2
#define ISC11 3

//General Interrupt Control Register - GICR
#define INT0 6
#define INT1 7
#define INT2 5

//General Interrupt Flag Register - GIFR
#define INTF0 6
#define INTF1 7
#define INTF2 5

//External Interrupt Requests
#define EXT_INT_0 __vector_1
#define EXT_INT_1 __vector_2
#define EXT_INT_2 __vector_3

//External Interrupt initialization 
void ISR_init(void);

//Set the Global Interrupts, set the I-bit in the status register to 1
#define sei() __asm__ __volatile__ ("sei" ::: "memory")

//CLear the Global Interrupts, set the I-bit in the status register to 0
#define cli() __asm__ __volatile__ ("cli" ::: "memory")

//ISR definition
#define ISR(INT_VECT)void INT_VECT(void) __attribute__ ((signal,used));\
void INT_VECT(void)

#endif /* ISR_H_ */