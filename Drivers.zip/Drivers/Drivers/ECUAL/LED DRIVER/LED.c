/*
 * LED.c
 *
 * Created: 7/15/2023 4:19:52 PM
 *  Author: Mazzen397
 */ 
#include "LED.h"
void LED_init(uint8_t LED_Port, uint8_t LED_Pin){
	DIO_init(LED_Pin,LED_Port,OUTPUT);
}
void LED_ON(uint8_t LED_Port, uint8_t LED_Pin){
	DIO_write(LED_Pin,LED_Port,HIGH);
}
void LED_OFF(uint8_t LED_Port, uint8_t LED_Pin){
	DIO_write(LED_Pin, LED_Port, LOW);
}
void LED_Toggle(uint8_t LED_Port, uint8_t LED_Pin){
	DIO_toggle(LED_Pin,LED_Port);
}