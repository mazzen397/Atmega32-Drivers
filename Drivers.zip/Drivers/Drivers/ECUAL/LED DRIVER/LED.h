/*
 * LED.h
 *
 * Created: 7/15/2023 4:19:59 PM
 *  Author: Mazzen397
 */ 


#ifndef LED_H_
#define LED_H_

#include "../../MCAL/DIO DRIVER/DIO.h"

//Define LEDs Ports & Pins
#define LED_1_PORT PORT_A
#define LED_1_PIN 0

//LED Function Prototypes
void LED_init(uint8_t LED_Port, uint8_t LED_Pin);
void LED_ON(uint8_t LED_Port, uint8_t LED_Pin);
void LED_OFF(uint8_t LED_Port, uint8_t LED_Pin);
void LED_Toggle(uint8_t LED_Port, uint8_t LED_Pin);

#endif /* LED_H_ */