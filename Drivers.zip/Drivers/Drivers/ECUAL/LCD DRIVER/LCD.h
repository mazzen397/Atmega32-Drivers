/*
 * LCD.h
 *
 * Created: 7/18/2023 9:58:21 PM
 *  Author: Mazzen397
 */ 


#ifndef LCD_H_
#define LCD_H_

#include "../../MCAL/TIMER0 DRIVER/TIMER.h"
#include "../../Register.h"
#include <util/delay.h>

/* In 8-bit mode, RS RW E on Port C and D0 -> D7 on Port D
   In 4-bit mode, RS RW E on Port C and D4 -> D5 also on Port C pins 26,27, 28 and 29*/
//Imp Pins
#define RS 0
#define RW 1
#define EN 2

//8-bit Register
#define LCD_Command_Dir DDRC	// Pins EN RS RR
#define LCD_Command_Port PORTC
#define LCD_Data_Dir DDRD
#define LCD_Data_Port PORTD

//8-bit LCD Function Prototypes
void LCD_8_bit_sendCommand(uint8_t Command);
void LCD_8_bit_init(void);
void LCD_8_bit_sendChar(uint8_t charData);
void LCD_8_bit_sendString(uint8_t *str);

//4-bit Register
#define LCD_Dir DDRC
#define LCD_Port PORTC

//4-bit LCD Function Prototypes
void LCD_4_bit_sendCommand(uint8_t Command);
void LCD_4_bit_init(void);
void LCD_4_bit_sendChar(uint8_t charData);
void LCD_4_bit_sendString(uint8_t *str);

//Clear Function
void LCD_4_bit_Clear(void);
void LCD_8_bit_Clear(void);
#endif /* LCD_H_ */