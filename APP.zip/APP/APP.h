/*
 * APP.h
 *
 * Created: 7/16/2023 11:12:32 PM
 *  Author: Mazzen397
 */ 


#ifndef APP_H_
#define APP_H_

#include "../ECUAL/LED DRIVER/LED.h"
#include "../ECUAL/BUTTON DRIVER/BUTTON.h"
#include "../ECUAL/LCD DRIVER/LCD.h"
#include "../ECUAL/KEYPAD DRIVER/KEYPAD.h"

void APP_init(void);
void APP_start(void);


#endif /* APP_H_ */