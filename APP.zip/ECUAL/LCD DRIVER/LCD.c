/*
 * LCD.c
 *
 * Created: 7/18/2023 9:58:08 PM
 *  Author: Mazzen397
 */ 
#include "LCD.h"

//8-bit LCD Mode
void LCD_8_bit_sendCommand(uint8_t Command){
	LCD_Data_Port = Command;
	LCD_Command_Port &= ~(1<<RS);	//Make RS pin low
	LCD_Command_Port &= ~(1<<RW);	//Make RW pin low
	//Generate high to low pulse from the Enable pin
	LCD_Command_Port |=  (1<<EN);	//High
	_delay_us(1);	//delay
	LCD_Command_Port &= ~(1<<EN);	//then low
	_delay_ms(3);
}
void LCD_8_bit_init(void){
	LCD_Command_Dir = 0xFF;	//Make LCD Command Port Direction as OUTPUT
	LCD_Data_Dir = 0xFF;	//Make LCD Data Port Direction as OUTPUT
	
	_delay_ms(100);
	
	LCD_8_bit_sendCommand (0x38);	//Initialization of 16x2 LCD in 8 bit Mode
	LCD_8_bit_sendCommand (0x0C);	//Display On Cursor Off
	LCD_8_bit_sendCommand (0x06);	//Auto Increment Cursor
	LCD_8_bit_sendCommand (0x01);	//Clear Display
	LCD_8_bit_sendCommand (0x80);	//Cursor at home Position
}
void LCD_8_bit_sendChar(uint8_t charData){
	LCD_Data_Port = charData;
	LCD_Command_Port |= (1<<RS);	//Make the RS pin High
	LCD_Command_Port &= ~(1<<RW);	//Make the RW pin Low
	//Generate high to low pulse from the Enable pin
	LCD_Command_Port |= (1<<EN);	//High
	_delay_us(1);	//delay
	LCD_Command_Port &= ~(1<<EN);	// Then Low
	_delay_ms(1);
}
void LCD_8_bit_sendString(uint8_t *str){
	uint16_t i;
	for ( i = 0; str[i] != 0; i++)	//Send each char of string till the Null character
	{
		LCD_8_bit_sendChar( str[i] );	//Call LCD data write
	}
}
void LCD_8_bit_Clear(void) {
	LCD_8_bit_sendCommand(0x01);
	_delay_ms(2);
}
//4-bit LCD Mode
void LCD_4_bit_sendCommand(uint8_t Command){
	LCD_Port = (LCD_Port & 0x0F) | (Command & 0xF0);	/* Sending upper nibble */
	LCD_Port &= ~ (1<<RS);	/* RS=0, command reg. */
	LCD_Port |= (1<<EN);	/* Enable pulse */
	_delay_us(1);
	LCD_Port &= ~ (1<<EN);
	_delay_us(200);
	LCD_Port = (LCD_Port & 0x0F) | (Command << 4);	/* Sending lower nibble */
	LCD_Port |= (1<<EN);
	_delay_us(1);
	LCD_Port &= ~ (1<<EN);
	_delay_ms(2);
}
void LCD_4_bit_init(){
	LCD_Dir = 0xFF;
	_delay_ms(100);
	
	LCD_4_bit_sendCommand(0x02);
	LCD_4_bit_sendCommand(0x28);
	LCD_4_bit_sendCommand(0x0C);
	LCD_4_bit_sendCommand(0x06);
	LCD_4_bit_sendCommand(0x01);
	//LCD_4_bit_sendCommand(0x80);
}
void LCD_4_bit_sendChar(uint8_t charData){
	LCD_Port = (LCD_Port & 0x0F) | (charData & 0xF0);
	LCD_Port |= (1 << RS);
	LCD_Port |= (1<<EN);
	_delay_us(1);
	LCD_Port &= ~(1<<EN);
	_delay_us(200);
	LCD_Port = (LCD_Port & 0x0F) | (charData << 4);
	LCD_Port |= (1<<EN);
	_delay_us(1);
	LCD_Port &= ~(1<<EN);
	_delay_ms(2);
}
void LCD_4_bit_sendString(uint8_t *str){
	uint16_t i;
	for ( i = 0; str[i] != 0; i++)	//Send each char of string till the Null character
	{
		LCD_4_bit_sendChar( str[i] );	//Call LCD data write
	}
}
void LCD_4_bit_Clear(void) {
	LCD_4_bit_sendCommand(0x01);
	_delay_ms(2);
}







