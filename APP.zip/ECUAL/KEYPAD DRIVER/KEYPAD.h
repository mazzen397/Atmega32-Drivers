/*
 * KEYPAD.h
 *
 * Created: 7/18/2023 9:58:44 PM
 *  Author: Mazzen397
 */ 


#ifndef KEYPAD_H_
#define KEYPAD_H_

#include "../../Register.h"

// Initialize the keypad
void keypad_init(void);

// Get the pressed key, returns '\0' if no key is pressed
uint8_t keypad_getKey(void);

#endif /* KEYPAD_H_ */