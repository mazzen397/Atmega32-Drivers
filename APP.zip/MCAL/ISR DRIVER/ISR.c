/*
 * ISR.c
 *
 * Created: 7/19/2023 12:42:06 AM
 *  Author: Mazzen397
 */ 
#include "ISR.h"
void ISR_init(void){
	
	//1. Enable Global Interrupt
	sei();
	
	//2. Choose Interrupt Sense
	MCUCR |= (1 << ISC00) | (1 << ISC01);
	
	//3. Enable External Interrupt
	GICR |= (1 << INT0);
	
}