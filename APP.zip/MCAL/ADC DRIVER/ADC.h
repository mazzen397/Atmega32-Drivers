/*
 * ADC.h
 *
 * Created: 7/18/2023 8:50:05 PM
 *  Author: Mazzen397
 */ 


#ifndef ADC_H_
#define ADC_H_
#include "../DIO DRIVER/DIO.h"

#define ADC_CH_0 0
#define VREF 5
#define ADC_STEP VREF/1024.0
#define SENSOR_RESOLUTION (float)1

//Function Prototypes
void ADC_init();
void ADC_start();


#endif /* ADC_H_ */