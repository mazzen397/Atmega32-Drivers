/*
 * DIO.h
 *
 * Created: 7/15/2023 3:40:19 PM
 *  Author: Mazzen397
 */ 


#ifndef DIO_H_
#define DIO_H_
#include "../../Register.h"

#define PORT_A 'A'
#define PORT_B 'B'
#define PORT_C 'C'
#define PORT_D 'D'

//Direction defines
#define IN 0
#define OUTPUT 1

//Value defines
#define HIGH 1
#define LOW 0

//Function Prototypes
void DIO_init(uint8_t pinNumber, uint8_t portNumber, uint8_t direction); //initialize DIO direction
void DIO_write(uint8_t pinNumber, uint8_t portNumber, uint8_t value); //Write data to DIO
void DIO_toggle(uint8_t pinNumber, uint8_t portNumber); //toggle DIO
uint8_t DIO_read(uint8_t pinNumber, uint8_t portNumber, uint8_t *value); //read DIO

#endif /* DIO_H_ */